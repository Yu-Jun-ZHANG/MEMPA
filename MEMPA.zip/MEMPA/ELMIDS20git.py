import hpelm
import pandas as pd
from mealpy import FloatVar
from mealpy.swarm_based import MPA
from sklearn.metrics import accuracy_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, StandardScaler
from intelelm import ElmRegressor, ElmClassifier, MhaElmRegressor, MhaElmClassifier
import numpy as np

global x_train, y_train, x_val, y_val, TZnum, concatenate_x_train, concatenate_y_train, tag, dim

def objective_functionELM(particle):
    global d,n,m,TZ
    global x_train, y_train, x_val, y_val,  concatenate_x_train, concatenate_y_train, tag, dim

    W = particle[:d * n * n].reshape(d * n, n)
    B = particle[d * n * n:d * n * n + d * n].reshape(d * n, 1)
    elm = hpelm.ELM(n, m)
    elm.add_neurons(d * n+1, "sigm")
    elm.W=W
    elm.B=B

    elm.train(x_train[:, TZ], y_train)
    y_pred = elm.predict(x_val[:,TZ])
    acc = accuracy_score(np.argmax(y_val, axis=1), np.argmax(y_pred, axis=1))

    return -1 * acc


dataset = pd.read_csv('train_data.csv')
df_shuffled = dataset.sample(frac=1)
X = df_shuffled.iloc[:, 1:].values
y = df_shuffled.iloc[:, 0].values

dataset = pd.read_csv('test_data.csv')
df_shuffled = dataset.sample(frac=1)
X_test = df_shuffled.iloc[:, 1:].values
y_test = df_shuffled.iloc[:, 0].values




besty=[]
scaler = MinMaxScaler()
X_train= scaler.fit_transform(X)
X_test = scaler.transform(X_test)
re=[]
YY=np.array([])
re1=[]

num_partitions =10
partitions_x=[]
partitions_y=[]

for i in range(num_partitions):
    class_num = np.bincount(y)
    data_index = []
    nums = np.round(np.min(class_num) * np.array([5, 20, 10, 1, 10]))

    for ii in range(len(class_num)):
        temp_label_index = np.where(y == ii)[0]
        if class_num[ii]>int(nums[ii]):
            resampled_indices = np.random.choice(temp_label_index, size=int(nums[ii]), replace=False)
            data_index.extend(resampled_indices)
        else:
            data_index.extend(temp_label_index)
    resampled_data = np.array(data_index)
    if i>0:
        partitions_x=np.vstack((X_train[resampled_data,:],partitions_x))
        partitions_y = np.vstack((y[resampled_data], partitions_y))
    else:
        partitions_x=X_train[resampled_data,:]
        partitions_y = y[resampled_data]

    Y_pre=np.array([])
    numbers=int(np.sum(nums))

j=0
ii=0
for i in range(numbers,num_partitions*numbers,numbers):
    # print(f'Partition {i + 1}: {partition}')
    x_train=partitions_x[ii:i]
    y_train=partitions_y[j]
    ii=i
    r = np.random.random(np.array(X_train).shape[1])
    J = np.argsort(r)
    J = np.sort(J)
    TZ = np.sort(J[:30+j])
    dim =len(TZ)
    x_val=X_train
    y_val=y

    from keras.utils import to_categorical
    y_train = to_categorical(y_train, 5)
    y_val = to_categorical(y_val, 5)
    j = j + 1
    global d, n, m
    d =2
    n = dim
    m = 5 #output numbers

    dimensions = d * n * n + d * n
    lb = np.zeros(dimensions)
    ub = np.ones(dimensions)

    problem_normal = {
        "obj_func": objective_functionELM,
        "bounds": FloatVar(lb, ub),
        "minmax": "min",
        "log_to": "console",
    }
    from MEMPAgit import OriginalMEMPA
    if np.random.random()>0.5:
        sma_model = OriginalMEMPA(epoch=30, pop_size=20)
    else:
        sma_model = OriginalMEMPA(epoch=1, pop_size=5)
    best_params = sma_model.solve(problem_normal, mode="thread", n_workers=16)
    X = best_params.solution

    W = X[:d * n * n].reshape(d * n, n)
    B = X[d * n * n:d * n * n + d * n].reshape(d * n, 1)
    elm = hpelm.ELM(n, m)
    elm.add_neurons(dim*d+1, "sigm")
    elm.W = W
    elm.B = B
    elm.train(x_train[:, TZ], y_train)
    y_pred = elm.predict(X_test[:, TZ])
    acc = accuracy_score(y_test, np.argmax(y_pred, axis=1))
    y_pred=np.argmax(y_pred, axis=1)
    if Y_pre.shape[0]==0:
        Y_pre=y_pred
    else:
        Y_pre=np.vstack((Y_pre,y_pred))
    listy=[]
    if j>2:
        for iii in range(Y_pre.shape[1]):
            most_common_values = np.argmax(np.bincount(Y_pre[:,iii]))
            listy.append(most_common_values)
print(f"acc：{accuracy_score(y_test, listy)}")
