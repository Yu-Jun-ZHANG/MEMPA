import numpy as np
from mealpy.optimizer import Optimizer
from scipy.stats import qmc

class OriginalMEMPA(Optimizer):


    def __init__(self, epoch: int = 10000, pop_size: int = 100, **kwargs: object) -> None:
        """
        Args:
            epoch (int): maximum number of iterations, default = 10000
            pop_size (int): number of population size, default = 100
        """
        super().__init__(**kwargs)
        self.epoch = self.validator.check_int("epoch", epoch, [1, 100000])
        self.pop_size = self.validator.check_int("pop_size", pop_size, [5, 10000])
        self.set_parameters(["epoch", "pop_size"])
        self.sort_flag = False

    def initialization(self):
        global seeds
        import sobol_seq
        self.FADS = 0.2
        self.P = 0.5
        self.seed=1
        self.best_temp=[]
        sobol = qmc.Sobol(self.problem.n_dims )
        population = sobol.random(self.pop_size)

        mapped_population = self.problem.lb + (self.problem.ub - self.problem.lb) * population

        if self.pop is None:
            self.pop = self.generate_population(self.pop_size)
        for i in range(self.pop_size):
            self.pop[i] = self.generate_agent(mapped_population[i, :])
    def evolve(self, epoch):
        from sklearn.preprocessing import MinMaxScaler
        """
        The main operations (equations) of algorithm. Inherit from Optimizer class

        Args:
            epoch (int): The current iteration
        """
        fits = np.array([agent.target.fitness for agent in self.pop]).reshape((1, -1))

        scaler = MinMaxScaler()
        CF = (1 - epoch/self.epoch)**(2 * epoch/self.epoch)
        RL = self.get_levy_flight_step(beta=1.5, multiplier=0.05, size=(self.pop_size, self.problem.n_dims), case=-1)
        RB = self.generator.standard_normal((self.pop_size, self.problem.n_dims))
        per1 = self.generator.permutation(self.pop_size)
        per2 = self.generator.permutation(self.pop_size)
        pop_new = []
        self.best_temp=self.g_best.solution
        for idx in range(0, self.pop_size):
            tag = 0
            R = self.generator.random(self.problem.n_dims)
            if epoch < self.epoch / 3:     # Phase 1 (Eq.12)

                step_size = RB[idx] * (self.g_best.solution - RB[idx] * self.pop[idx].solution)
                pos_new = self.pop[idx].solution + self.P * R * step_size

            elif self.epoch / 3 < epoch < 2*self.epoch / 3:     # Phase 2 (Eqs. 13 & 14)
                if idx > self.pop_size / 2:
                    step_size = RB[idx] * (RB[idx] * self.g_best.solution - self.pop[idx].solution)
                    pos_new = self.g_best.solution + self.P * CF * step_size
                else:
                    step_size = RL[idx] * (self.g_best.solution - RL[idx] * self.pop[idx].solution)
                    pos_new = self.pop[idx].solution + self.P * R * step_size
            else:       # Phase 3 (Eq. 15)
                if self.generator.random()<0.1:
                        step_size = RL[idx] * (RL[idx] * self.g_best.solution - self.pop[idx].solution)
                        pos_new = self.g_best.solution + self.P * CF * step_size
                else:
                    JK = np.argsort(np.random.random(self.pop_size))
                    jj = JK[0]
                    BF1 = round(1 + self.generator.random())
                    BF2 = round(1 + self.generator.random())
                    mutualVector = np.mean(np.vstack([self.pop[idx].solution, self.g_best.solution]), axis=0)
                    pos_new = self.g_best.solution + self.P * CF * RL[idx] * (RL[idx]*self.pop[idx].solution-
                             BF1 * mutualVector)
                    best_temp = self.g_best.solution + self.P * CF * RL[idx] * (RL[idx]*self.g_best.solution -
                                                                              BF2 * mutualVector)
                    tag=1


            if tag >0:
                best_temp = self.correct_solution(best_temp)
                best = self.generate_empty_agent(best_temp)
                best.target = self.get_target(best_temp)
                if best.target.fitness<self.g_best.target.fitness:
                    self.g_best=best
                tag=0

            pos_new = self.correct_solution(pos_new)
            if self.generator.random() < self.FADS:
                u = np.where(self.generator.random(self.problem.n_dims) < self.FADS, 1, 0)
                pos_new = pos_new + CF * (self.problem.lb + self.generator.random(self.problem.n_dims) * (self.problem.ub - self.problem.lb)) * u
            else:
                r = self.generator.random()
                step_size = (self.FADS * (1 - r) + r) * (self.pop[per1[idx]].solution - self.pop[per2[idx]].solution)
                pos_new = pos_new + step_size
            pos_new = self.correct_solution(pos_new)
            agent = self.generate_empty_agent(pos_new)

            pop_new.append(agent)
            if self.mode not in self.AVAILABLE_MODES:
                agent.target = self.get_target(pos_new)
                if agent.target.fitness < self.pop[idx].target.fitness:
                    self.pop[idx] = self.get_better_agent(self.pop[idx], agent, self.problem.minmax)
                else:
                    dis = Distance(agent.solution, self.pop[idx].solution)
                    delta = abs(agent.target.fitness - self.pop[idx].target.fitness)
                    threshold = np.exp(-(delta / dis))
                    if self.generator.random() < threshold:
                        self.pop[idx] = agent
        if self.mode in self.AVAILABLE_MODES:
            pop_new = self.update_target_for_population(pop_new)
            self.pop = self.greedy_selection_population(self.pop, pop_new, self.problem.minmax)
def Distance(indiX, indiY):
    dis = 0
    Epsilon = 2 ** (-52)
    for i in range(len(indiX)):
        dis += abs(indiX[i] - indiY[i])
    return dis + Epsilon